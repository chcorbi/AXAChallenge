Notes: AXA Challenge
------
[!] faire une fonction dédiée au formatage de du 'submission.txt' file
[!] faire une fonction temporaire de bootstrap d'un train et d'un test

[!] le temps d'entaînement et de prédiciton n'est pas critique

[?] réflechir sur les fenêtres des mini-batchs et leur pas de translation
[?] réflechir à combien de modèles train k = 1 2 ... 20 ...
[!] mettre un modèle au dessus des autres modèles afin de pondérer correctement
    modèles entre eux
[?] choisir comment faire la cross-validation
[!] favoriser la prédiciton à la hausse, prendre là LinExp loss function
[!] toujours prendre note des choix et des avancées fait, pour l'exposé final
[!] ne pas faire du ML au sens strict,
    max de la semaine (de l'année dernière) + la tendance
[!] 'renault', le mettre à zéro
